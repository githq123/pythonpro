from django.apps import AppConfig


class Jxlg03Config(AppConfig):
    name = 'jxlg03'
