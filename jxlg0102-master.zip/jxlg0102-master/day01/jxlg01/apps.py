from django.apps import AppConfig


class Jxlg01Config(AppConfig):
    name = 'jxlg01'
