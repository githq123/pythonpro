from django.apps import AppConfig


class Jxlg02Config(AppConfig):
    name = 'jxlg02'
